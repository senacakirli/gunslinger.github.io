﻿namespace FishNet.Component.Prediction
{
    /// <summary>
    /// Type of prediction movement being used.
    /// </summary>
    public enum RigidbodyType : byte
    {
        Rigidbody = 0,
        Rigidbody2D = 1
    }

}