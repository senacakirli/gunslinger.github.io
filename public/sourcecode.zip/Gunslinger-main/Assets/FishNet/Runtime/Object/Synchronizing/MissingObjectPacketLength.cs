﻿namespace FishNet.Object
{

    internal enum MissingObjectPacketLength : int
    {
        Reliable = -1,
        PurgeRemaiming = -2,
    }


}