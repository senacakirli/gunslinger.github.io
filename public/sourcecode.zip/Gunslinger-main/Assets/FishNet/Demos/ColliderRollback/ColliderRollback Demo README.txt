THIS DEMO REQUIRES FISH-NETWORKING PRO

- Start two editors or builds.
- Press play on each.
- Run one as server, and the other as client.

Red shows where the object was rolled back to on the server.
Green shows where the object actually was on server.

Rollback indicators in demo will not be correct when firing as clientHost.
