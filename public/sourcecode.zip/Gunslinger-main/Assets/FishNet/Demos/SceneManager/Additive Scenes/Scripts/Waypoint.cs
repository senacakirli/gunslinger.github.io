﻿using UnityEngine;

namespace FishNet.Demo.AdditiveScenes
{

    public class Waypoint : MonoBehaviour
    {
        public byte WaypointIndex;
    }

}