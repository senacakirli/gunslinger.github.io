THIS DEMO REQUIRES FISH-NETWORKING PRO

- Enable LOD inside the Fish-Networking > Developer menu.
- Open scene.
- Select LOD Tester in scene and slide LOD Level.
- Press Play.

Can be tested as clientHost, or server and client separate.
LOD Level cannot be changed at runtime.
A level of 1 is the same as not using LOD.