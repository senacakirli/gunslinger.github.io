﻿using UnityEngine;

namespace FishNet.Example.ComponentStateSync
{


    public class AMonoScript : MonoBehaviour
    {

        private void Start()
        {
            //Start is here to show enabled toggle within inspector.
        }
    }


}