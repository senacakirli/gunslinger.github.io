Git URL:
https://github.com/Abdelfattah-Radwan/FishNet.CodeAnalysis