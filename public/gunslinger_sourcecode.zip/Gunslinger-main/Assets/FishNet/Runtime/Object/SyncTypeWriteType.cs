﻿namespace FishNet.Object
{

    internal enum SyncTypeWriteType
    {
        Observers = 0,
        Owner = 1,
        All = 2,
    }


}