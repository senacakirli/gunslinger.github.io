﻿
namespace FishNet.Broadcast
{
    /// <summary>
    /// Include this interface on types intended to be used with Broadcast.
    /// </summary>
    public interface IBroadcast { }
}